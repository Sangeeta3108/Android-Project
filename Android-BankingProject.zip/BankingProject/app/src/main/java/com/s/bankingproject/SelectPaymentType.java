package com.s.bankingproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class SelectPaymentType extends AppCompatActivity {

    Button btnCheckBalance, btnPayBills, btnTransfer;
    UserData userData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_payment_type);

        userData = (UserData) getIntent().getSerializableExtra("userData");


        btnCheckBalance = findViewById(R.id.btnCheckBalance);
        btnPayBills = findViewById(R.id.btnPayBills);
        btnTransfer = findViewById(R.id.btnTransfer);

        btnCheckBalance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SelectPaymentType.this, AccountListActivity.class);
                intent.putExtra("userData", userData);
                intent.putExtra("isFromBalanceCheck", true);
                startActivity(intent);
            }
        });

        btnPayBills.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SelectPaymentType.this, SelectUtility.class);
                intent.putExtra("userData", userData);
                startActivity(intent);
            }
        });

        btnTransfer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SelectPaymentType.this, AccountListActivity.class);
                intent.putExtra("userData", userData);
                intent.putExtra("isFromTransfer",true);
                startActivity(intent);
            }
        });


    }
}