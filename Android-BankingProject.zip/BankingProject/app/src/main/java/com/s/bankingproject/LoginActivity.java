package com.s.bankingproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class LoginActivity extends AppCompatActivity {

    EditText edtCardNumber, edtPinNumber;
    Button btnLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        addUserData();
        edtCardNumber = findViewById(R.id.edtCardNumber);
        edtPinNumber = findViewById(R.id.edtPinNumber);
        btnLogin = findViewById(R.id.btnLogin);
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (edtCardNumber.getText().toString().isEmpty()) {
                    edtCardNumber.requestFocus();
                    edtCardNumber.setError("please enter Card number");
                } else if (edtPinNumber.getText().toString().isEmpty()) {
                    edtPinNumber.requestFocus();
                    edtPinNumber.setError("please enter Pin number");
                } else {

                    for (int i = 0; i < SessionData.I().getUserDataList().size(); i++) {
                        if (edtCardNumber.getText().toString().equals(
                                SessionData.I().getUserDataList().get(i).getCardNumber()) &&
                                edtPinNumber.getText().toString().equals(
                                        SessionData.I().getUserDataList().get(i).getPinNumber())) {

                            Intent intent = new Intent(LoginActivity.this, SelectPaymentType.class);
                            intent.putExtra("userData", SessionData.I().getUserDataList().get(i));
                            SessionData.makeIntentAsClearHistory(intent);
                            startActivity(intent);
                            break;
                        }
//                        else {
//                            Toast.makeText(LoginActivity.this, "Invalid user", Toast.LENGTH_LONG).show();
//                        }

                    }

                }

            }
        });


    }

    private void addUserData() {
        List<UserData> userDataList = new ArrayList<>();
        userDataList.add(new UserData(1, "5556 2822 1230 2525",
                "1234", "User1",
                20000, "Master Card","78965412"));

        userDataList.add(new UserData(1, "4556 0000 1230 2555",
                "5678", "User1",
                15000, "Visa Card","78965412"));

        userDataList.add(new UserData(1, "8856 6622 1230 2588",
                "9876", "User1",
                25000, "Credit Card","78965412"));


        userDataList.add(new UserData(2, "6688 5566 0022 2213",
                "5432", "User2",
                40000, "Visa Card","74565412"));

        userDataList.add(new UserData(2, "7755 0001 1230 2288",
                "1234", "User2",
                5000, "Master Card","74565412"));

        userDataList.add(new UserData(3, "4585 6548 0025 3333",
                "5622", "User3",
                20000, "Master Card","74512312"));
        SessionData.I().setUserDataList(userDataList);
    }
}