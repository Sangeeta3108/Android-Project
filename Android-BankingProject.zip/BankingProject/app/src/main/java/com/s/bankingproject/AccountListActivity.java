package com.s.bankingproject;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class AccountListActivity extends AppCompatActivity {
    List<UserData> list = new ArrayList<>();
    UserData data;
    Boolean isFromBalanceCheck;
    Boolean isFromTransfer;
    String amount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_list);
        data = (UserData) getIntent().getSerializableExtra("userData");
        amount = getIntent().getStringExtra("amount");
        isFromBalanceCheck = getIntent().getBooleanExtra("isFromBalanceCheck", false);
        isFromTransfer = getIntent().getBooleanExtra("isFromTransfer", false);
        RecyclerView recyclerView = findViewById(R.id.rvAccounts);
        list.clear();
        for (int i = 0; i < SessionData.I().getUserDataList().size(); i++) {
            if (SessionData.I().getUserDataList().get(i).getId() == data.getId()) {
                list.add(SessionData.I().getUserDataList().get(i));
            }
        }
        AccountAdapter mAdapter = new AccountAdapter(list, new AccountAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(UserData item, int index) {
                if (isFromTransfer) {
                    Intent intent = new Intent(AccountListActivity.this, MainActivity.class);
                    intent.putExtra("userData", item);
                    startActivity(intent);
                } else {
                    openDialog(item);
                }
            }
        });
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(mAdapter);
    }

    private void openDialog(UserData data) {

        String title;
        String message;
        if (isFromBalanceCheck) {
            title = "Account Balance";
            message = "Your Total Balance is " + data.getAccountBalance();
        } else {
            title = "Payment Done";
            message = "Your bill is Payed";

            for (int i = 0; i < SessionData.I().getUserDataList().size(); i++) {
                if (SessionData.I().getUserDataList().get(i).getCardNumber().equals(data.getCardNumber())) {
                    double balance = SessionData.I().getUserDataList().get(i).getAccountBalance()
                            - Double.parseDouble(amount);
                    SessionData.I().getUserDataList().get(i).setAccountBalance(balance);
                }
            }
        }

        AlertDialog alertDialog = new AlertDialog.Builder(AccountListActivity.this).create();
        alertDialog.setTitle(title);
        alertDialog.setMessage(message);
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        Intent intent = new Intent(AccountListActivity.this, SelectPaymentType.class);
                        SessionData.makeIntentAsClearHistory(intent);
                        startActivity(intent);
                        dialog.dismiss();
                    }
                });
        alertDialog.show();


    }
}