package com.s.bankingproject;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText edtCardNumber, edtPinNumber, edtAmount;
    Button btnLogin;
    UserData data;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edtCardNumber = findViewById(R.id.edtCardNumber);
        edtPinNumber = findViewById(R.id.edtPinNumber);
        edtAmount = findViewById(R.id.edtAmount);
        btnLogin = findViewById(R.id.btnLogin);
        data = (UserData) getIntent().getSerializableExtra("userData");
        edtCardNumber.setText(data.cardNumber);
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (edtCardNumber.getText().toString().isEmpty()) {
                    edtCardNumber.requestFocus();
                    edtCardNumber.setError("please enter Sender Account No. ");
                } else if (edtPinNumber.getText().toString().isEmpty()) {
                    edtPinNumber.requestFocus();
                    edtPinNumber.setError("please enter Receiver Account No.");
                } else if (edtAmount.getText().toString().isEmpty()) {
                    edtAmount.requestFocus();
                    edtAmount.setError("please enter Amount");
                } else if (data.getAccountBalance() < Double.parseDouble(edtAmount.getText().toString())) {
                    Toast.makeText(MainActivity.this,"Please check your balance",Toast.LENGTH_LONG).show();
                } else {
                    for (int i = 0; i < SessionData.I().getUserDataList().size(); i++) {
                        if (SessionData.I().getUserDataList().get(i).getCardNumber()
                                .equals(edtPinNumber.getText().toString())) {
                            double balance = SessionData.I().getUserDataList().get(i).getAccountBalance()
                                    + Double.parseDouble(edtAmount.getText().toString());
                            SessionData.I().getUserDataList().get(i).setAccountBalance(balance);
                        }
                        if (SessionData.I().getUserDataList().get(i).getCardNumber()
                                .equals(edtCardNumber.getText().toString())) {
                            double balance = SessionData.I().getUserDataList().get(i).getAccountBalance()
                                    - Double.parseDouble(edtAmount.getText().toString());
                            SessionData.I().getUserDataList().get(i).setAccountBalance(balance);
                        }
                    }
                    openDialog();
                }

            }
        });
    }

    private void openDialog() {
        AlertDialog alertDialog = new AlertDialog.Builder(MainActivity.this).create();
        alertDialog.setTitle("Transfer");
        alertDialog.setMessage("Your transfer is Done");
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        Intent intent = new Intent(MainActivity.this, SelectPaymentType.class);
                        SessionData.makeIntentAsClearHistory(intent);
                        startActivity(intent);
                        dialog.dismiss();

                    }
                });
        alertDialog.show();


    }
}