package com.s.bankingproject;


import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

import androidx.recyclerview.widget.RecyclerView;

public class AccountAdapter extends RecyclerView.Adapter<AccountAdapter.MyViewHolder> {

    private List<UserData> list;
    OnItemClickListener onItemClickListener;

    public AccountAdapter(List<UserData> list, OnItemClickListener onItemClickListener) {
        this.list = list;
        this.onItemClickListener = onItemClickListener;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView txtBankName, txtAccountNumber;

        public MyViewHolder(View view) {
            super(view);
            txtBankName = view.findViewById(R.id.txtBankName);
            txtAccountNumber = view.findViewById(R.id.txtAccountNumber);
        }
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_account, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, final int position) {
        final UserData data = list.get(position);
        holder.txtBankName.setText(data.cardName);
        holder.txtAccountNumber.setText(data.cardNumber);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onItemClickListener.onItemClick(data, position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    interface OnItemClickListener {

        void onItemClick(UserData item, int index);

    }

}
