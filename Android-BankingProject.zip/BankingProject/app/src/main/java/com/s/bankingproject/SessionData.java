package com.s.bankingproject;

import android.content.Intent;

import java.util.ArrayList;
import java.util.List;

public class SessionData {
    static SessionData instance;

    private List<UserData> userDataList = new ArrayList<>();

    public SessionData() {
    }

    public static void makeIntentAsClearHistory(Intent intent) {
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
    }

    public static SessionData I() {
        if (instance == null) {
            instance = new SessionData();
        }
        return instance;
    }

    public List<UserData> getUserDataList() {
        return userDataList;
    }

    public void setUserDataList(List<UserData> userDataList) {
        this.userDataList = userDataList;
    }
}
