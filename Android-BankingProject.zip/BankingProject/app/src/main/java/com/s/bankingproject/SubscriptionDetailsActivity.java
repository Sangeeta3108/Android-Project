package com.s.bankingproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class SubscriptionDetailsActivity extends AppCompatActivity {

    EditText edtSubscription, edtAmount;
    Button btnPay;
    UserData data;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_subscription_details);
        data = (UserData) getIntent().getSerializableExtra("userData");
        edtSubscription = findViewById(R.id.edtSubscription);
        edtAmount = findViewById(R.id.edtAmount);
        btnPay = findViewById(R.id.btnPay);
        btnPay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (edtSubscription.getText().toString().isEmpty()) {
                    edtSubscription.requestFocus();
                    edtSubscription.setError("please enter Subscription");
                } else if (edtAmount.getText().toString().isEmpty()) {
                    edtAmount.requestFocus();
                    edtAmount.setError("please enter Amount");
                } else {
                    for (int i = 0; i < SessionData.I().getUserDataList().size(); i++) {
                        if (edtSubscription.getText().toString().equals(
                                SessionData.I().getUserDataList().get(i).getSubscriptionNumber())) {
                            Intent intent = new Intent(SubscriptionDetailsActivity.this,
                                    AccountListActivity.class);
                            intent.putExtra("userData", data);
                            intent.putExtra("amount", edtAmount.getText().toString());
                            intent.putExtra("isFromBalanceCheck", false);
                            startActivity(intent);
                            break;
                        }
                    }
                }
            }
        });

    }
}