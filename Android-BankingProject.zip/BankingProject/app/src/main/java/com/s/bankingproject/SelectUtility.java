package com.s.bankingproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class SelectUtility extends AppCompatActivity {
    Button btnCheckBalance, btnPayBills, btnTransfer, btnGas;
  UserData data;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_utility);
    data = (UserData) getIntent().getSerializableExtra("userData");
        btnCheckBalance = findViewById(R.id.btnHydro);
        btnPayBills = findViewById(R.id.btnWater);
        btnTransfer = findViewById(R.id.btnPhone);
        btnGas = findViewById(R.id.btnGas);

        btnCheckBalance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SelectUtility.this, SubscriptionDetailsActivity.class);
                intent.putExtra("userData", data);
                startActivity(intent);

            }
        });

        btnPayBills.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SelectUtility.this, SubscriptionDetailsActivity.class);
                intent.putExtra("userData", data);
                startActivity(intent);
            }
        });

        btnTransfer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SelectUtility.this, SubscriptionDetailsActivity.class);
                intent.putExtra("userData", data);
                startActivity(intent);
            }
        });
        btnGas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SelectUtility.this, SubscriptionDetailsActivity.class);
                intent.putExtra("userData", data);
                startActivity(intent);
            }
        });


    }
}