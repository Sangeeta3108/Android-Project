package com.s.bankingproject;

import java.io.Serializable;

public class UserData implements Serializable {
    int id;
    String cardNumber;
    String pinNumber;
    String userName;
    double accountBalance;
    String cardName;
    String subscriptionNumber;

    public UserData() {
    }


    public UserData(int id, String cardNumber, String pinNumber, String userName, double accountBalance, String cardName, String subscriptionNumber) {
        this.id = id;
        this.cardNumber = cardNumber;
        this.pinNumber = pinNumber;
        this.userName = userName;
        this.accountBalance = accountBalance;
        this.cardName = cardName;
        this.subscriptionNumber = subscriptionNumber;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public String getPinNumber() {
        return pinNumber;
    }

    public void setPinNumber(String pinNumber) {
        this.pinNumber = pinNumber;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public double getAccountBalance() {
        return accountBalance;
    }

    public void setAccountBalance(double accountBalance) {
        this.accountBalance = accountBalance;
    }

    public String getCardName() {
        return cardName;
    }

    public void setCardName(String cardName) {
        this.cardName = cardName;
    }

    public String getSubscriptionNumber() {
        return subscriptionNumber;
    }

    public void setSubscriptionNumber(String subscriptionNumber) {
        this.subscriptionNumber = subscriptionNumber;
    }
}
